
package model;

public class Barang {

    // Atribut private
    private String kodeBarang;
    private String namaBarang;
    private String kategori;
    private int stok;

    // Constructor kosong
    public Barang() {
    }

    // Constructor dengan parameter
    public Barang(String kodeBarang, String namaBarang,
                  String kategori, int stok) {
        this.kodeBarang = kodeBarang;
        this.namaBarang = namaBarang;
        this.kategori = kategori;
        this.stok = stok;
    }

    // Getter kodeBarang
    public String getKodeBarang() {
        return kodeBarang;
    }

    // Setter kodeBarang
    public void setKodeBarang(String kodeBarang) {
        this.kodeBarang = kodeBarang;
    }

    // Getter namaBarang
    public String getNamaBarang() {
        return namaBarang;
    }

    // Setter namaBarang
    public void setNamaBarang(String namaBarang) {
        this.namaBarang = namaBarang;
    }

    // Getter kategori
    public String getKategori() {
        return kategori;
    }

    // Setter kategori
    public void setKategori(String kategori) {
        this.kategori = kategori;
    }

    // Getter stok
    public int getStok() {
        return stok;
    }

    // Setter stok
    public void setStok(int stok) {
        this.stok = stok;
    }
}
