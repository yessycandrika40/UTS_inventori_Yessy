
package view;

import dao.BarangDao;
import model.Barang;
import java.sql.SQLException;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class FromBarang extends javax.swing.JFrame {

    private BarangDao dao = new BarangDao();

private DefaultTableModel model;

    public FromBarang() {
        initComponents();
        model = (DefaultTableModel) tblBarang.getModel();

    tampilData();
        
    }
    
    
private void resetForm() {

    txtKode.setText("");
    txtNama.setText("");
    cmdKategori.setSelectedIndex(0);
    txtStok.setText("");

    txtKode.requestFocus();
}

    private void tampilData() {

    model.setRowCount(0);

    try {

        List<Barang> daftar = dao.tampilkan();

        for (Barang b : daftar) {

            model.addRow(new Object[]{
                b.getKodeBarang(),
                b.getNamaBarang(),
                b.getKategori(),
                b.getStok()
            });

        }

    } catch (SQLException e) {

        JOptionPane.showMessageDialog(
            this,
            "Gagal menampilkan data: " + e.getMessage()
        );

        
    }
    
}


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtNama = new javax.swing.JTextField();
        txtKode = new javax.swing.JTextField();
        txtStok = new javax.swing.JTextField();
        cmdKategori = new javax.swing.JComboBox<>();
        btnUbah = new javax.swing.JButton();
        btnHapus = new javax.swing.JButton();
        btnBersihkan = new javax.swing.JButton();
        btnSimpan = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblBarang = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel1.setText("Pengelolaan Data Barang Laboratorium");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        jLabel2.setText("Nama Barang :");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 130, -1, -1));

        jLabel3.setText("Kategori :");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 170, -1, -1));

        jLabel4.setText("Stok :");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 210, -1, -1));

        jLabel5.setText("Kode Barang :");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 90, -1, -1));

        txtNama.setText("Mouse USB");
        getContentPane().add(txtNama, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 130, 340, -1));

        txtKode.setText("BRG01");
        getContentPane().add(txtKode, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 90, 340, -1));

        txtStok.setText("15");
        txtStok.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtStokActionPerformed(evt);
            }
        });
        getContentPane().add(txtStok, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 210, 340, -1));

        cmdKategori.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Komputer", "Jaringan", "Alat Ukur", " " }));
        getContentPane().add(cmdKategori, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 170, 340, -1));

        btnUbah.setText("Ubah");
        btnUbah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUbahActionPerformed(evt);
            }
        });
        getContentPane().add(btnUbah, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 610, 100, -1));

        btnHapus.setText("Hapus");
        btnHapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHapusActionPerformed(evt);
            }
        });
        getContentPane().add(btnHapus, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 610, 80, -1));

        btnBersihkan.setText("Bersihkan");
        btnBersihkan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBersihkanActionPerformed(evt);
            }
        });
        getContentPane().add(btnBersihkan, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 610, -1, -1));

        btnSimpan.setText("Simpan");
        btnSimpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSimpanActionPerformed(evt);
            }
        });
        getContentPane().add(btnSimpan, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 610, -1, -1));

        tblBarang.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Kode Barang", "Nama Barang", "Kategori", "Stok"
            }
        ));
        tblBarang.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblBarangMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblBarang);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 290, 510, 270));

        setBounds(0, 0, 815, 755);
    }// </editor-fold>//GEN-END:initComponents

    private void btnSimpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSimpanActionPerformed
        // TODO add your handling code here:
        

    try {
        String kode = txtKode.getText().trim();
        String nama = txtNama.getText().trim();
        String kategori = cmdKategori.getSelectedItem().toString();
        String stokText = txtStok.getText().trim();

        if (kode.isEmpty() || nama.isEmpty() || stokText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Semua data wajib diisi!");
            return;
        }

        int stok = Integer.parseInt(stokText);

        if (stok < 0) {
            JOptionPane.showMessageDialog(this, "Stok tidak boleh negatif!");
            return;
        }

        Barang b = new Barang(kode, nama, kategori, stok);

        if (dao.simpan(b)) {
            JOptionPane.showMessageDialog(this, "Data berhasil disimpan!");
            tampilData();
            resetForm();
        }

    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "Stok harus berupa angka!");
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Gagal menyimpan: " + e.getMessage());
    }


    }//GEN-LAST:event_btnSimpanActionPerformed

    private void btnUbahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUbahActionPerformed
        // TODO add your handling code here:
        

    try {
        String kode = txtKode.getText().trim();
        String nama = txtNama.getText().trim();
        String kategori = cmdKategori.getSelectedItem().toString();
        String stokText = txtStok.getText().trim();

        if (kode.isEmpty() || nama.isEmpty() || stokText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Pilih data yang ingin diubah!");
            return;
        }

        int stok = Integer.parseInt(stokText);

        if (stok < 0) {
            JOptionPane.showMessageDialog(this, "Stok tidak boleh negatif!");
            return;
        }

        Barang b = new Barang(kode, nama, kategori, stok);

        if (dao.ubah(b)) {
            JOptionPane.showMessageDialog(this, "Data berhasil diubah!");
            tampilData();
            resetForm();
        } else {
            JOptionPane.showMessageDialog(this, "Data tidak ditemukan!");
        }

    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "Stok harus berupa angka!");
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Gagal mengubah: " + e.getMessage());
    }

    }//GEN-LAST:event_btnUbahActionPerformed

    private void btnHapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHapusActionPerformed
        // TODO add your handling code here:
        
    try {
        String kode = txtKode.getText().trim();

        if (kode.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Pilih data yang ingin dihapus!");
            return;
        }

        int konfirmasi = JOptionPane.showConfirmDialog(
            this,
            "Yakin ingin menghapus barang " + kode + "?",
            "Konfirmasi Hapus",
            JOptionPane.YES_NO_OPTION
        );

        if (konfirmasi == JOptionPane.YES_OPTION) {

            if (dao.hapus(kode)) {
                JOptionPane.showMessageDialog(this, "Data berhasil dihapus!");
                tampilData();
                resetForm();
            } else {
                JOptionPane.showMessageDialog(this, "Data tidak ditemukan!");
            }
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Gagal menghapus: " + e.getMessage());
    }

    }//GEN-LAST:event_btnHapusActionPerformed

    private void btnBersihkanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBersihkanActionPerformed
        // TODO add your handling code here:
        

    resetForm();



    }//GEN-LAST:event_btnBersihkanActionPerformed

    private void tblBarangMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblBarangMouseClicked
        // TODO add your handling code here:
        

    int baris = tblBarang.getSelectedRow();

    if (baris != -1) {

        txtKode.setText(model.getValueAt(baris, 0).toString());

        txtNama.setText(model.getValueAt(baris, 1).toString());

        cmdKategori.setSelectedItem(
            model.getValueAt(baris, 2).toString()
        );

        txtStok.setText(model.getValueAt(baris, 3).toString());

        txtKode.setEditable(false);
    }


    }//GEN-LAST:event_tblBarangMouseClicked

    private void txtStokActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtStokActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtStokActionPerformed


    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FromBarang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FromBarang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FromBarang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FromBarang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FromBarang().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBersihkan;
    private javax.swing.JButton btnHapus;
    private javax.swing.JButton btnSimpan;
    private javax.swing.JButton btnUbah;
    private javax.swing.JComboBox<String> cmdKategori;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblBarang;
    private javax.swing.JTextField txtKode;
    private javax.swing.JTextField txtNama;
    private javax.swing.JTextField txtStok;
    // End of variables declaration//GEN-END:variables
}
