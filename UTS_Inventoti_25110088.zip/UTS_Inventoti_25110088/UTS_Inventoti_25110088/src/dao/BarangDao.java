
package dao;

import model.Barang;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class BarangDao {

    // 1. SIMPAN BARANG
    public boolean simpan(Barang b) throws SQLException {

        String sql = "INSERT INTO barang "
                + "(kode_barang, nama_barang, kategori, stok) "
                + "VALUES (?, ?, ?, ?)";

        try (Connection conn = Koneksii.getConnection()) {

            if (conn == null) {
                throw new SQLException("Koneksi database gagal.");
            }

            try (PreparedStatement ps = conn.prepareStatement(sql)) {

                ps.setString(1, b.getKodeBarang());
                ps.setString(2, b.getNamaBarang());
                ps.setString(3, b.getKategori());
                ps.setInt(4, b.getStok());

                return ps.executeUpdate() > 0;
            }
        }
    }

    // 2. TAMPILKAN SEMUA BARANG
    public List<Barang> tampilkan() throws SQLException {

        List<Barang> daftar = new ArrayList<>();

        String sql = "SELECT * FROM barang ORDER BY kode_barang";

        try (Connection conn = Koneksii.getConnection()) {

            if (conn == null) {
                throw new SQLException("Koneksi database gagal.");
            }

            try (PreparedStatement ps = conn.prepareStatement(sql);
                 ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {

                    Barang b = new Barang(
                        rs.getString("kode_barang"),
                        rs.getString("nama_barang"),
                        rs.getString("kategori"),
                        rs.getInt("stok")
                    );

                    daftar.add(b);
                }
            }
        }

        return daftar;
    }

    // 3. UBAH BARANG
    public boolean ubah(Barang b) throws SQLException {

        String sql = "UPDATE barang SET "
                + "nama_barang=?, kategori=?, stok=? "
                + "WHERE kode_barang=?";

        try (Connection conn = Koneksii.getConnection()) {

            if (conn == null) {
                throw new SQLException("Koneksi database gagal.");
            }

            try (PreparedStatement ps = conn.prepareStatement(sql)) {

                ps.setString(1, b.getNamaBarang());
                ps.setString(2, b.getKategori());
                ps.setInt(3, b.getStok());
                ps.setString(4, b.getKodeBarang());

                return ps.executeUpdate() > 0;
            }
        }
    }

    // 4. HAPUS BARANG
    public boolean hapus(String kode) throws SQLException {

        String sql = "DELETE FROM barang WHERE kode_barang=?";

        try (Connection conn = Koneksii.getConnection()) {

            if (conn == null) {
                throw new SQLException("Koneksi database gagal.");
            }

            try (PreparedStatement ps = conn.prepareStatement(sql)) {

                ps.setString(1, kode);

                return ps.executeUpdate() > 0;
            }
        }
    }
}
