
package dao;

import java.sql.Connection;

public class TesKoneksi {

    public static void main(String[] args) {

        Connection conn = Koneksii.getConnection();

        if (conn != null) {
            System.out.println(
                "Koneksi database berhasil!"
            );

            try {
                conn.close();
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        } else {
            System.out.println(
                "Koneksi database gagal!"
            );
        }
    }
}
